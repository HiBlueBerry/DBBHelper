local drawableSpriteStruct=require("structs.drawable_sprite")
local utils=require("utils")
local xnaColors = require("consts.xna_colors")
local AnalogNoiseGlitchEffect={}
AnalogNoiseGlitchEffect.name="DBBHelper/AnalogNoiseGlitchEffect"

AnalogNoiseGlitchEffect.fieldOrder={
    "x","y",
    "width","height",
    "Velocity","Strength",
    "JitterVelocity","JitterThreshold",
    "MaskTexture","GreyJitter",

}
Preset={
    "objects/DBB_Items/DBBGeneralEffectTexture/AllPassMask",
    "objects/DBB_Items/DBBGeneralEffectTexture/CircleMask",
}
--maximumValue=1.0
AnalogNoiseGlitchEffect.fieldInformation={
    Velocity={
        fieldType="number",
        minimumValue=0
    },
    Strength={
        fieldType="number",
        minimumValue=0
    },
    JitterVelocity={
        fieldType="number",
        minimumValue=0
    },
    JitterThreshold={
        fieldType="number",
        minimumValue=0,
        maximumValue=1.0
    },
    MaskTexture={
        options=Preset,
        editable=true,
    },
}
AnalogNoiseGlitchEffect.placements={
    name="AnalogNoiseGlitchEffect",
    data={
        width=8,
        height=8,
        Velocity=1.0,
        Strength=0.25,
        JitterVelocity=1.0,
        JitterThreshold=0.5,
        GreyJitter=false,
        MaskTexture="objects/DBB_Items/DBBGeneralEffectTexture/AllPassMask",
    }
}

AnalogNoiseGlitchEffect.fillColor = function(room, entity)
    local color=xnaColors.Pink
    return {color[1] * 0.3, color[2] * 0.3, color[3] * 0.3, 0.6}
end

AnalogNoiseGlitchEffect.borderColor = function(room, entity)
    local color=xnaColors.Violet 
    return {color[1] * 0.8, color[2] * 0.8, color[3] * 0.8, 0.8}
end
return AnalogNoiseGlitchEffect