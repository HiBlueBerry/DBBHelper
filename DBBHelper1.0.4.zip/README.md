# DBBHelper
DBBHelper 
    Version 1.0.4

    Update:
        Adjust: Adjust the logic of AlignedText to make them to be compatible with the flip function of the original game.
        Adjust: Add more function to AlignedText, now you can use {space} and {n} to achieve the function of the key "Space" and the key "Enter" in one line raw text. 
        Adjust: Add transition to InvisibleLight(or Advanced) to make the light changes smoothly when entering or leaving a room.
        Add new entity FogEffect: The most amazing entity in this Update, try to use this to create countless possibilities! This is still in experimental period, but I think I have 
        completed the compatible with flip and zoom function of the original game.
        Add new entity FogEffectControl: A controller using a tag to control relative FogEffect Entity.
    Features:

        1.CloudZipper
        This is a combination of cloud and zipper.

        2.InvisibleLight(or Advanced)
        Sometimes you just need a simple light source without any visible entities, and this entity may help you.

        3.DarkIn
        If you stay away from the light source for too long, Madeline will die. As you approach the light source, Madeline will gradually restore light radius.

        4.ConditionalLightningBreakerBox(ConditionalLightning)
        Lightning (breaker box) with a flag that enables you to control when this entity should exist.

        5.Wave and distort
        I just took out the wave and distortion effect separately, and you can use a mask image to create various unique visual effects.

        6.LaserGenerator(Translate)
        Deadly laser with a flag to control its movement.

        7.ScreenBlackEdge(Horizontal and Vertical)
        Used to add borders to the upper (or left) and lower (or right) sides of the screen to achieve different picture proportions.

        8.Rope
        A simple physically simulated rope.

        9.Aligned Text
        CoreMessage that allows left (or right) aligned text.

        10.FogEffect(and its controller)


    TODO:
        More ForeGroundEffect...
        Music visualization...







