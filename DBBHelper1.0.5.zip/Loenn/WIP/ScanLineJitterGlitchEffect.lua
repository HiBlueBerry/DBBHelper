local drawableSpriteStruct=require("structs.drawable_sprite")
local utils=require("utils")
local xnaColors = require("consts.xna_colors")
local ScanLineJitterGlitchEffect={}
ScanLineJitterGlitchEffect.name="DBBHelper/ScanLineJitterGlitchEffect"

ScanLineJitterGlitchEffect.fieldOrder={
    "x","y",
    "width","height",
    "Velocity", "Strength",
    "Angle",
}
--maximumValue=1.0
ScanLineJitterGlitchEffect.fieldInformation={
    Strength={
        fieldType="number",
        minimumValue=0.0,
    },
    Velocity={
        fieldType="number",
        minimumValue=0.0,
    },
}
ScanLineJitterGlitchEffect.placements={
    name="ScanLineJitterGlitchEffect",
    data={
        width=8,
        height=8,
        Velocity=0.05,
        Strength=0.05,
        Angle=0.0,
    }
}

ScanLineJitterGlitchEffect.fillColor = function(room, entity)
    local color=xnaColors.Pink
    return {color[1] * 0.3, color[2] * 0.3, color[3] * 0.3, 0.6}
end

ScanLineJitterGlitchEffect.borderColor = function(room, entity)
    local color=xnaColors.Violet
    return {color[1] * 0.8, color[2] * 0.8, color[3] * 0.8, 0.8}
end

return ScanLineJitterGlitchEffect