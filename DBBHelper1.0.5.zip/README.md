# DBBHelper
DBBHelper 
    Version 1.0.5

    Update:
        BugFix: Fixed the unnatural disappearance of the rope when leaving the room.
        BugFix: Fixed the bug that a fog effect controller can only control one fog effect.
        Improvement: Add scale control for fog effect.
        Add: GodLight2D, a powerful light effect entity based on RayMarching.
        Add(prototype): ProgramSky, a backdrop that keeps changing colors.
    Warning:
        At present, FogEffect and GodLight2D needs the performance support of GPU very much. 
        Therefore, using them extensively on some computers with weak computing power(As I konw, one of them is Intel UHD Graphics family) will lead to the obvious jamming of the game. 
        I am currently trying to improve their efficiency. 
        In addition, the implementation method of the fog entity has been greatly changed in this update, so there may be a variety of strange bugs. 
        If found, the current solution is to open the loenn, update a map at will, or choose to restart the level in the game pause UI. 
        Of course, if you find any bugs, please leave a message for me in the comment area of gamebanana. 
        For some personal reasons, I rarely use GitHub at present, but I occasionally browse the comment area of gamebanana.
    Features:

        1.CloudZipper
        This is a combination of cloud and zipper.

        2.InvisibleLight(or Advanced)
        Sometimes you just need a simple light source without any visible entities, and this entity may help you.

        3.DarkIn
        If you stay away from the light source for too long, Madeline will die. As you approach the light source, Madeline will gradually restore light radius.

        4.ConditionalLightningBreakerBox(ConditionalLightning)
        Lightning (breaker box) with a flag that enables you to control when this entity should exist.

        5.Wave and distort
        I just took out the wave and distortion effect separately, and you can use a mask image to create various unique visual effects.

        6.LaserGenerator(Translate)
        Deadly laser with a flag to control its movement.

        7.ScreenBlackEdge(Horizontal and Vertical)
        Used to add borders to the upper (or left) and lower (or right) sides of the screen to achieve different picture proportions.

        8.Rope
        A simple physically simulated rope.

        9.Aligned Text
        CoreMessage that allows left (or right) aligned text.

        10.FogEffect(and its controller)
            Powerful entity to make and control FBM fog.
        11.GodLight2D
            Powerful entity to make Tyndall Light Effect.

    TODO:
        Effenciency Problem!!!!







